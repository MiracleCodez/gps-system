# DESIGN AND IMPLEMENTATION OF A WEB-BASED GPS LOCATION TRACKING AND MANAGEMENT SYSTEM FOR NYANZA DISTRICT

**A final-year thesis submitted to the University of Lay Adventists of Kigali (UNILAK) in partial fulfilment of the requirements for the award of the Bachelor of Science degree in Computing and Information Sciences**

**Student:** [Student Name]  
**Registration Number:** [Registration Number]  
**Supervisor:** [Supervisor Name]  
**Campus:** Nyanza Campus  
**Academic Year:** [Academic Year]

---

# DEDICATION

This work is dedicated to my parents, family members, lecturers, and friends whose encouragement, patience, and moral support enabled me to complete this academic project. It is also dedicated to students and public-service practitioners who seek practical and affordable ways of using information technology to improve the management of mobile activities in their communities.

# DECLARATION

I, **[Student Name]**, declare that this thesis entitled **“Design and Implementation of a Web-Based GPS Location Tracking and Management System for Nyanza District”** is my original work and has not been submitted to any other institution for the award of an academic qualification. All sources used in this work have been acknowledged through appropriate citations and references.

**Student signature:** ____________________  
**Date:** ____________________

# ACKNOWLEDGMENT

I thank God for the strength and guidance that enabled me to complete this study. I sincerely thank my supervisor, **[Supervisor Name]**, for the academic direction, constructive comments, and continuous support provided during the development of this thesis. I am grateful to the lecturers and staff of the University of Lay Adventists of Kigali for the knowledge and skills acquired throughout my programme.

I also appreciate the support of my classmates, friends, and family members. Their encouragement assisted me during the requirements analysis, implementation, testing, and preparation of this document. Finally, I acknowledge the public information made available by Nyanza District and the Government of Rwanda, which helped to establish the institutional and geographical context of this study.

# TABLE OF CONTENT

**Front matter**

- Dedication
- Declaration
- Acknowledgment
- Table of Content
- List of Figures
- List of Symbols & Abbreviations
- Abstract

**Chapter 1: Introduction**

- 1.1 Background to the study
- 1.2 Problem statement
- 1.3 Objectives
  - 1.3.1 General objective
  - 1.3.2 Specific objectives
- 1.4 Significance
  - 1.4.1 Personal
  - 1.4.2 Institutional
  - 1.4.3 Public interest
- 1.5 Scope of the study
- 1.6 Expected results
- 1.7 Organization of the study

**Chapter 2: Literature Review**

- 2.1 Introduction
- 2.2 Definitions
  - 2.2.1 Key concepts of the topic
  - 2.2.2 IT concepts
- 2.3 Comparative study of similar systems
- 2.4 Personal contribution

**Chapter 3: Analysis of Existing System**

- 3.1 Introduction
- 3.2 Organization overview
- 3.3 Vision, mission and development objectives
- 3.4 Description of existing system activities
  - 3.4.1 Tracker registration
  - 3.4.2 Location reporting
  - 3.4.3 Trip monitoring
  - 3.4.4 Trip reporting and record keeping
- 3.5 Weaknesses of the existing system
- 3.6 Proposed solutions

**Chapter 4: Analysis & Design of New System**

- 4.1 Introduction
- 4.2 Development methodologies, models and tools
- 4.3 Function diagram
- 4.4 Context diagram
- 4.5 Data flow diagram (level 0)
- 4.6 Functional and non-functional requirements
- 4.7 Database design
  - 4.7.1 Entities
  - 4.7.2 Relationships and cardinality
  - 4.7.3 Attributes
  - 4.7.4 Physical model
  - 4.7.5 Logical model
  - 4.7.6 Data dictionary

**Chapter 5: Testing, Results and Discussion**

- 5.1 Introduction
- 5.2 Testing approach
- 5.3 Test cases and results
- 5.4 Functional results
- 5.5 Non-functional results
- 5.6 Discussion of findings
- 5.7 Limitations of the evaluation

**Chapter 6: Summary, Conclusion and Recommendations**

- 6.1 Summary of the study
- 6.2 Conclusion
- 6.3 Recommendations
- 6.4 Final conclusion

- References

# LIST OF FIGURES

- **Figure 3.1:** Existing tracker registration process
- **Figure 3.2:** Existing location reporting process
- **Figure 3.3:** Existing trip monitoring process
- **Figure 3.4:** Existing trip reporting and record-keeping process
- **Figure 4.1:** Function diagram of the proposed GPS management system
- **Figure 4.2:** Context diagram of the proposed GPS management system
- **Figure 4.3:** Level 0 data flow diagram
- **Figure 4.4:** Entity relationship diagram

# LIST OF SYMBOLS & ABBREVIATIONS

| Symbol or abbreviation | Meaning |
|---|---|
| API | Application Programming Interface |
| BSc | Bachelor of Science |
| DBMS | Database Management System |
| DFD | Data Flow Diagram |
| ERD | Entity Relationship Diagram |
| GPS | Global Positioning System |
| HTML | HyperText Markup Language |
| HTTP | HyperText Transfer Protocol |
| HTTPS | HyperText Transfer Protocol Secure |
| JSON | JavaScript Object Notation |
| NISR | National Institute of Statistics of Rwanda |
| OOM | Object-Oriented Methodology |
| REST | Representational State Transfer |
| SQL | Structured Query Language |
| UNILAK | University of Lay Adventists of Kigali |
| UML | Unified Modeling Language |

# ABSTRACT

This study presents the design and implementation of a web-based GPS location tracking and management system for Nyanza District. The study responds to the difficulty of obtaining timely, centralized, and reliable information about the location and movement of field personnel, mobile teams, or vehicles when monitoring depends on telephone calls, informal messages, and manually maintained records. The proposed system uses a smartphone browser as a low-cost GPS tracking device. The browser requests location permission, captures latitude, longitude, speed, accuracy, and time, and sends the data to a central web server. An administrator accesses a web dashboard to register trackers, view the latest locations on an interactive map, inspect location history, and manage trips.

The system was designed using object-oriented analysis principles and UML-oriented modelling. The implementation uses HTML, CSS, and JavaScript for the client interface, Node.js and Express for the application server, SQLite for relational data storage, and Leaflet with OpenStreetMap for map visualization. The database contains devices, locations, and trips. The system is intended as a practical prototype that can be demonstrated without owning a car or purchasing a dedicated GPS unit, because a smartphone carried by a walking user can simulate the movement of a vehicle or field team.

The expected contribution is a transparent, affordable, and extensible platform for location monitoring. The system is not presented as a replacement for a production fleet-management platform without further work. Production deployment would require authenticated users, role-based access, HTTPS, stronger privacy controls, retention policies, and testing with district stakeholders. The completed prototype establishes the technical basis for these future extensions.

**Keywords:** GPS, location tracking, fleet management, smartphone geolocation, web application, Nyanza District, information system.

# CHAPTER 1: INTRODUCTION

## 1.1 Background to the study

The management of mobile activities depends on knowing where people, vehicles, or field teams are located and whether they are following planned activities. In a district environment, such information can support coordination of field visits, inspection activities, public-service operations, transport, emergency response, and other tasks that require movement between locations. When location information is available only through telephone calls or informal messages, managers cannot easily obtain a shared and historical view of activity.

A Global Positioning System (GPS) receiver determines a device’s position by processing signals from navigation satellites. Modern smartphones combine GPS capability with mobile connectivity and web browsers. A smartphone can therefore collect location coordinates and transmit them to a server without the installation of a dedicated vehicle tracker. This approach is suitable for a student prototype because it reduces hardware cost and allows a walking user to simulate the movement of a vehicle or field worker.

Nyanza District is one of the eight districts in Rwanda’s Southern Province. The official district profile describes it as a historical and cultural centre of Rwanda and states that it is composed of 10 sectors, 51 cells, and 420 villages. The district’s economic activities include agriculture, livestock, trade, and tourism [1]. These administrative and economic characteristics create a context in which timely information about mobile activities can be valuable for coordination and service delivery.

The transport sector is also relevant to the study. Rwanda’s Ministry of Infrastructure identifies transport responsibilities that include government fleet management and traffic management. The ministry further emphasizes mobility, accessibility, reliability, safety, monitoring, and evaluation of transport services [2]. A small web-based tracking system cannot address all national transport requirements, but it can demonstrate how digital location records may support monitoring and reporting at an operational level.

The study is academically conducted at the University of Lay Adventists of Kigali. UNILAK’s official profile states that the university has a Nyanza Campus and that its mission includes education, scientific and technological research, and community service [3]. The proposed system is therefore aligned with a computing research project that applies software development skills to a practical district-level problem.

## 1.2 Problem statement

The problem addressed by this study is the absence of a simple and affordable platform for centralized GPS location monitoring in the selected Nyanza District context. In a manual or decentralized arrangement, a field user may communicate a location by telephone or message, while a supervisor records the information in a notebook, spreadsheet, or separate communication thread. Such an arrangement does not provide a continuously updated map, consistent timestamps, automated history, or a reliable method of comparing activities over time.

The absence of centralized location records can lead to delayed decision-making, incomplete trip histories, difficulty verifying reported movements, and additional administrative work. It also limits the ability of a manager to view several trackers from one interface. Dedicated vehicle GPS systems may solve some of these problems, but they introduce hardware, installation, subscription, and maintenance costs that are not appropriate for an initial BSc prototype.

This study therefore proposes a smartphone-based web system that captures GPS coordinates, stores them in a relational database, and displays the information on a management dashboard. The project uses a smartphone as the tracking device, so the researcher does not need to own a car or dedicated tracking hardware to demonstrate the system.

## 1.3 Objectives

### 1.3.1 General objective

To design and implement a web-based GPS location tracking and management system for Nyanza District.

### 1.3.2 Specific objectives

1. To examine the existing methods used for registering, communicating, monitoring, and recording mobile activities in the selected study context.
2. To identify the functional and non-functional requirements of a smartphone-based GPS management system.
3. To design the system architecture, process models, database structure, and user interfaces of the proposed system.
4. To implement a smartphone tracking interface that requests location permission and transmits GPS coordinates to a web server.
5. To implement an administrative dashboard for tracker registration, map-based monitoring, telemetry inspection, and route-history review.
6. To implement a relational database for storing trackers, location points, and trip records.
7. To test the system using functional, integration, validation, and usability-oriented test cases.

## 1.4 Significance

### 1.4.1 Personal

The study enables the researcher to apply software engineering knowledge to a complete information-system project. It provides practical experience in requirements analysis, object-oriented modelling, REST API development, database design, web programming, browser geolocation, map visualization, testing, and technical documentation. The project also creates a foundation for future research into geofencing, route optimization, spatial databases, and mobile applications.

### 1.4.2 Institutional

For UNILAK, the project provides an applied computing case study connected to community service and technological research. It may support teaching and demonstration in systems analysis, web development, database management, and information systems. The project can also be extended by future students who wish to add authentication, PostgreSQL/PostGIS, analytics, notifications, or dedicated GPS-device integration.

### 1.4.3 Public interest

A low-cost location-management prototype may be useful to public institutions, small transport operators, delivery teams, non-governmental organizations, and community-service programmes that cannot immediately purchase dedicated tracking infrastructure. The system may improve visibility of mobile activities and reduce dependence on fragmented communication. However, location data is sensitive; public deployment must therefore include consent, access control, data minimization, secure transmission, and clear retention rules.

## 1.5 Scope of the study

The geographical context of the study is Nyanza District in Rwanda. The academic and development context is UNILAK, particularly the Nyanza Campus and the computing discipline. The system scope is a web-based GPS location tracking and management prototype.

Functionally, the system covers tracker registration, smartphone geolocation permission, transmission of latitude and longitude, storage of speed and accuracy, latest-location display, tracker status, trip start and end, and route-history review. The system includes a dashboard for an administrator or fleet manager and a phone tracker page for the field user.

The system does not include vehicle engine diagnostics, fuel sensors, dedicated GPS hardware, automatic emergency dispatch, payment processing, facial recognition, national-scale public transport planning, or production-grade multi-tenant security. These areas are identified as possible future extensions rather than current deliverables.

## 1.6 Expected results

The study is expected to produce a working web application through which a smartphone can act as a GPS tracking device. The system should allow an administrator to register a tracker and view the tracker’s latest position on an interactive map. It should store valid location points in a relational database and provide a history that can be reviewed after movement has taken place.

The study is also expected to produce a documented system design comprising requirements, process diagrams, a context diagram, a level 0 data-flow diagram, a function diagram, an entity relationship diagram, a logical data model, a physical database model, and a data dictionary. Finally, the study should provide test evidence showing whether the implemented functions satisfy the specified requirements.

## 1.7 Organization of the study

Chapter One introduces the study by presenting its background, problem, objectives, significance, scope, expected results, and organization. Chapter Two reviews key concepts and compares similar categories of systems. Chapter Three analyses the existing processes considered in the study context, identifies their weaknesses, and proposes solutions. Chapter Four presents the development methodology and the design of the proposed system, including the function diagram, context diagram, data-flow diagram, requirements, and database design.

# CHAPTER 2: LITERATURE REVIEW

## 2.1 Introduction

This chapter reviews concepts related to GPS location tracking, district administration, mobility management, and information systems. It defines the main terms used in the study, explains the information-technology concepts that support the proposed solution, compares similar system categories, and identifies the contribution of the present study.

## 2.2 Definitions

### 2.2.1 Key concepts of the topic

**District.** A district is a local administrative area established to organize public administration and the delivery of services. In this study, Nyanza District refers to the district in Rwanda’s Southern Province that includes sectors, cells, and villages under a decentralized administrative structure. The official district profile states that Nyanza has 10 sectors, 51 cells, and 420 villages [1].

**GPS.** The Global Positioning System is a satellite-based positioning system that enables a receiver to estimate its geographical position. In this study, GPS refers to the location capability available on a smartphone and accessed through the browser’s geolocation interface.

**Location coordinate.** A location coordinate is a numeric representation of position, normally expressed as latitude and longitude. The system also records time, speed, and estimated accuracy for each coordinate observation.

**Tracker.** A tracker is a registered device that submits location information to the system. In the prototype, the tracker is normally a smartphone browser. The design also allows the concept to represent a future dedicated GPS device.

**Fleet management.** Fleet management is the coordination, monitoring, and administration of vehicles or mobile assets. In this study, the term is used broadly to include the management of registered trackers, trips, positions, and operational history. The prototype is not limited to vehicles and can represent field workers or other mobile teams.

**Trip.** A trip is a period of movement that begins when the user selects “Start trip” and ends when the user selects “End trip”. A trip is associated with one tracker and may contain many location records.

**Geofencing.** Geofencing is the creation of a virtual geographic boundary that can trigger an event when a tracker enters or leaves an area. Geofencing is not implemented in the current MVP but is a relevant future extension.

**Route history.** Route history is the ordered collection of location points recorded for a tracker. The dashboard displays these points as a table and can connect them as a route line on the map.

**Real-time monitoring.** Real-time monitoring is the observation of recent system events with a short delay between data collection and display. In this prototype, the tracker sends updates when the browser reports a new position and the dashboard refreshes recent device data periodically.

### 2.2.2 IT concepts

**Information.** Information is data that has been processed or organized so that it has meaning for a user. A latitude value alone is data; a map marker labelled with the tracker name, time, speed, and status is information useful for management.

**Software.** Software is a collection of programs, configuration, and related files that instruct a computing device to perform tasks. The GPS system includes server software, browser-side scripts, stylesheets, database initialization logic, and configuration files.

**System.** A system is a set of connected components that interact to achieve a purpose. The proposed system contains users, a smartphone tracker, browser pages, an API, validation logic, a database, and a map interface.

**Information system.** An information system is an organized combination of people, procedures, data, hardware, software, and communication resources used to collect, process, store, and distribute information. The proposed GPS system is an information system because it transforms location observations into operational information for a manager.

**Database.** A database is an organized collection of related data that can be stored, queried, updated, and protected. The prototype uses SQLite to store devices, locations, and trips.

**Application Programming Interface.** An API is a defined interface through which software components exchange requests and responses. The system’s REST API receives location submissions and returns device, location, and trip information as JSON.

**Web application.** A web application is software accessed through a web browser and supported by server-side processing. The proposed system has a dashboard page and a phone tracker page served by the Express web server.

**User interface.** A user interface is the visible and interactive part of a system through which a person performs tasks. The dashboard provides map, device, telemetry, and history controls, while the tracker page provides tracking and trip controls.

## 2.3 Comparative study of similar systems

The proposed system can be compared with four broad categories of existing solutions. Dedicated vehicle GPS platforms usually provide continuous tracking, hardware integration, geofencing, driver behaviour analysis, and alerts. Their main disadvantage for this study is the cost and complexity of purchasing, installing, and maintaining dedicated hardware.

Mobile fleet applications use smartphone location services and often provide route monitoring, driver communication, proof of delivery, and reports. They are closer to the proposed solution because they use a phone as the tracking device. However, many commercial applications are subscription-based and may include features that are unnecessary for a small BSc prototype.

Manual reporting systems use telephone calls, messaging applications, paper forms, or spreadsheets. They require little technical infrastructure, but they do not provide consistent real-time visibility, automatic coordinate validation, or a unified route history. They also create additional work when a supervisor needs to compare multiple activities.

Public mapping platforms provide map visualization and routing but do not necessarily provide a complete management workflow. The proposed system combines the map interface with tracker registration, location persistence, trip records, and an administrative dashboard. Its distinctive contribution is therefore not the invention of GPS or maps; it is the integration of accessible smartphone geolocation with a small, understandable management system that can be demonstrated without a vehicle.

| System category | Tracking device | Central history | Map dashboard | Hardware cost | Suitability for this study |
|---|---|---:|---:|---:|---|
| Dedicated fleet platform | Installed GPS unit | Yes | Yes | High | Useful as a reference, costly for prototype |
| Commercial mobile fleet app | Smartphone | Yes | Usually | Subscription | Similar concept, less transparent for study |
| Manual calls and spreadsheets | Phone or paper | Fragmented | No | Low | Current-problem reference |
| Proposed GPS system | Smartphone browser | Yes | Yes | Low | Appropriate for BSc prototype |

The comparison indicates that the proposed system occupies a practical middle ground. It provides more structure than manual reporting while avoiding the hardware requirements of a dedicated fleet platform. It remains a prototype and should not be evaluated as equivalent to mature commercial products in uptime, security, or large-scale analytics.

## 2.4 Personal contribution

The personal contribution of this study is the design and implementation of an end-to-end smartphone-based GPS information system adapted to the Nyanza District context. The work combines requirements analysis, process modelling, object-oriented thinking, database design, REST API implementation, browser geolocation, and map visualization in one coherent prototype.

The study also contributes a low-cost demonstration method. Because the smartphone itself acts as the tracking device, the researcher can walk with the phone and generate a realistic route without owning a car. This makes the system accessible for academic demonstration while preserving the essential data flow of a vehicle or field-team tracking system.

# CHAPTER 3: ANALYSIS OF EXISTING SYSTEM

## 3.1 Introduction

This chapter analyses the existing process considered by the study before the introduction of the proposed web-based system. Since no formal district workflow records or interview transcripts were supplied for this draft, the existing activities are modelled as a manual or semi-manual location-reporting arrangement. Before final submission, the researcher should validate these descriptions through interviews, observation, questionnaires, or official process documents and replace any assumption that does not match the selected department or organization.

The analysis focuses on four activities: tracker registration, location reporting, trip monitoring, and trip reporting. Each activity is described with a process figure so that the transition from the existing arrangement to the proposed system is clear.

## 3.2 Organization overview

Nyanza District is located in Rwanda’s Southern Province and is one of the province’s eight districts. According to its official profile, the district is historically and culturally significant, contains 10 sectors, 51 cells, and 420 villages, and has economic activities that include agriculture, livestock, trade, and tourism [1]. These characteristics mean that district operations may involve coordination across multiple administrative and physical locations.

The academic host institution for this study is the University of Lay Adventists of Kigali. UNILAK’s official profile states that the university was established by the Federation of Adventist Parents Associations for the Development of Education in Rwanda and that it operates campuses in Kigali, Nyanza, and Rwamagana. The profile also identifies education, scientific and technological research, and community service as central institutional purposes [3].

For this study, Nyanza District is the application context, while UNILAK provides the academic setting in which the system is analysed and developed. The system is not claimed to be an officially commissioned district information system. It is an academic prototype designed to demonstrate how a district-level organization could centralize location monitoring.

## 3.3 Vision, mission and development objectives

The official Nyanza District profile presents the district as a historical and cultural centre and describes a development focus involving cultural tourism and sustainable development [1]. In the context of this study, the relevant operational vision is a district administration supported by timely, reliable, and accessible information for coordinating mobile activities.

The relevant mission for the proposed system is to support coordination and accountability by making recent location information available to authorized users through a centralized web interface. This system mission is consistent with the national transport emphasis on mobility, accessibility, reliability, safety, monitoring, and evaluation [2].

The development objectives of the proposed system are to reduce reliance on fragmented communication, centralize location records, improve visibility of active trackers, support trip documentation, and provide a technical foundation for future alerts and spatial analysis.

## 3.4 Description of existing system activities

### 3.4.1 Tracker registration

In the assumed existing arrangement, a new vehicle, phone, or field user is identified through a conversation between an administrator and a supervisor. Basic information may be written in a notebook, spreadsheet, or message thread. The assignment of the device to a user or route is then communicated informally.

This procedure can be adequate for a small number of users, but it does not create one authoritative tracker register. Names, device identifiers, assignments, and status changes may be stored in different places. Figure 3.1 shows the process model used for this study.

![Existing tracker registration process](rendered/existing-tracker-registration.png)

*Figure 3.1: Existing tracker registration process.*

### 3.4.2 Location reporting

In the assumed existing arrangement, a field user travels and communicates a location only when a supervisor requests an update or when the user considers it necessary. The supervisor records the reported location and time manually. If no update is requested, the movement may not create a central record.

This procedure depends on availability of the user and supervisor, accuracy of verbal descriptions, and consistency of manual recording. Figure 3.2 presents the process.

![Existing location reporting process](rendered/existing-location-reporting.png)

*Figure 3.2: Existing location reporting process.*

### 3.4.3 Trip monitoring

Trip monitoring in the assumed existing arrangement depends on a starting communication, periodic verbal updates, and follow-up when a delay or incident is reported. The supervisor does not continuously see the position on a map. Monitoring therefore depends on the frequency and quality of communication.

Figure 3.3 illustrates this manual monitoring process. The repeated follow-up loop indicates why a centralized recent-location view could reduce unnecessary communication and improve situational awareness.

![Existing trip monitoring process](rendered/existing-trip-monitoring.png)

*Figure 3.3: Existing trip monitoring process.*

### 3.4.4 Trip reporting and record keeping

After a trip, the supervisor collects calls, messages, and paper notes and attempts to compare reported times and locations. A summary report may then be prepared and filed or shared with management. Because the information is collected from separate sources, historical analysis can be difficult and the completeness of the report depends on the quality of the records received.

Figure 3.4 shows the assumed process for trip reporting and record keeping.

![Existing trip reporting process](rendered/existing-trip-reporting.png)

*Figure 3.4: Existing trip reporting and record-keeping process.*

## 3.5 Weaknesses of the existing system

The existing arrangement has limited centralization. Tracker information and location updates may be distributed across notebooks, spreadsheets, phone calls, and messaging platforms. This makes it difficult to maintain a single current register.

The arrangement also provides limited real-time visibility. A supervisor can know the location only after a user communicates it. If the user is unavailable, busy, or experiencing connectivity problems, the supervisor may not receive an update. The system therefore cannot reliably show the latest position of every mobile user.

Manual records can contain inconsistent names, missing timestamps, imprecise place descriptions, and duplicated entries. It is also difficult to draw a route from text messages or to calculate the distance and time travelled without additional processing.

The current arrangement does not automatically validate coordinates because it usually records descriptions rather than latitude and longitude. It also does not provide a standard method for showing whether a tracker is online, offline, or stale.

Finally, manual reporting increases administrative workload. A supervisor must request updates, transcribe information, compare records, and prepare summaries. The arrangement may also expose sensitive location information through uncontrolled communication channels.

## 3.6 Proposed solutions

The proposed system introduces a centralized tracker register containing the tracker name, type, status, and creation time. This replaces dispersed identification records with a database record that can be queried by the dashboard and API.

The smartphone tracker page uses browser geolocation to capture latitude, longitude, speed, accuracy, and time. It sends the observation to the server as a structured JSON request. The server validates the device and geographic ranges before storing the point in the locations table.

The dashboard provides a map-based view of latest locations and automatically refreshes recent device information. A manager can select a tracker to inspect its coordinates, speed, accuracy, last-seen time, and historical route. This reduces dependence on repeated phone calls and creates a consistent record for review.

The trip functions provide explicit start and end events. A trip is associated with the tracker and can be queried later. This creates a foundation for future reports, distance calculations, route-deviation alerts, and performance analysis.

The proposed system does not remove the need for human judgment or field communication. It provides a complementary digital record. In a production setting, it should be combined with user consent, secure authentication, retention controls, and procedures for responding to inaccurate or unavailable location data.

# CHAPTER 4: ANALYSIS & DESIGN OF NEW SYSTEM

## 4.1 Introduction

This chapter presents the analysis and design of the proposed web-based GPS location tracking and management system. It describes the development methodology, modelling approach, tools, functions, system boundary, data flows, requirements, and database design. The design is based on a smartphone tracker, a web dashboard, an Express API, and a relational SQLite database.

## 4.2 Development methodologies, models and tools

### 4.2.1 Unified Process

The study adopts the Unified Process as a guiding software-development framework. The Unified Process is iterative and incremental. Its phases are inception, elaboration, construction, and transition. During inception, the problem and project scope are defined. During elaboration, requirements, architecture, and risks are analysed. During construction, the API, database, tracker interface, and dashboard are implemented. During transition, the system is tested, documented, and prepared for demonstration.

The use of iterations is appropriate because the project contains technical uncertainty around browser geolocation, network access, map rendering, and data persistence. A basic vertical slice can be built first: one smartphone submits one location and the dashboard displays it. Additional capabilities such as trips, history, and device registration can then be added without changing the entire design.

### 4.2.2 Unified Modeling Language

Unified Modeling Language (UML) is used to communicate the structure and behaviour of the system. The function diagram presents the main functional decomposition. The context diagram presents external actors and the system boundary. The data-flow diagram shows movement of information between processes and data stores. The ERD presents the database entities and their relationships. Together, the models create a traceable connection between requirements, implementation, and data storage.

### 4.2.3 Object-Oriented Methodology

Object-Oriented Methodology (OOM) analyses a system in terms of objects, their data, and their responsibilities. In this system, important objects include Device, Location, Trip, TrackerClient, Dashboard, and ApiService. A Device has an identity and status. A Location belongs to a Device and records a geospatial observation. A Trip belongs to a Device and represents a period of movement. The object-oriented perspective supports modular code and makes it easier to extend the system with users, geofences, alerts, or maintenance records.

### 4.2.4 Development tools

The client interface uses HTML, CSS, and JavaScript. The server uses Node.js and Express.js. SQLite is used as the relational database for the prototype. Leaflet.js renders interactive map markers and route lines, while OpenStreetMap provides map tiles. Git and GitHub provide version control. Mermaid source files are used for diagrams, and the system can be run with `npm install` followed by `npm start`.

## 4.3 Function diagram

The function diagram decomposes the proposed system into tracker management, location tracking, trip management, and monitoring/reporting. Tracker management registers and selects devices. Location tracking requests permission, captures coordinates, validates observations, and stores them. Trip management creates and completes trip records. Monitoring and reporting provide the map, telemetry, and route history used by the administrator.

![Function diagram](rendered/function-diagram.png)

*Figure 4.1: Function diagram of the proposed GPS location tracking and management system.*

## 4.4 Context diagram

The context diagram shows the proposed system as one central process and identifies the two primary external actors. The administrator or fleet manager sends tracker and monitoring requests and receives map, status, telemetry, and history information. The smartphone tracker user grants permission, starts or stops tracking, and starts or ends trips. The system receives location data from the tracker and provides stored information to the administrator.

![Context diagram](rendered/system-context.png)

*Figure 4.2: Context diagram of the proposed GPS location tracking and management system.*

## 4.5 Data flow diagram (level 0)

The level 0 data-flow diagram decomposes the system into tracker management, location capture, and fleet monitoring. The administrator interacts with tracker management and receives monitoring outputs. The smartphone tracker provides coordinates and trip actions to the location-capture process. Validated location points are stored in the locations data store, while device and trip information are stored in their respective data stores.

![Level 0 data-flow diagram](rendered/dfd-level-0.png)

*Figure 4.3: Level 0 data-flow diagram of the proposed GPS location tracking and management system.*

## 4.6 Functional and non-functional requirements

### 4.6.1 Functional requirements

| Requirement ID | Functional requirement |
|---|---|
| FR-01 | The system shall allow an administrator to register a tracker with a name and device type. |
| FR-02 | The system shall list all registered trackers. |
| FR-03 | The phone tracker shall request browser location permission before tracking. |
| FR-04 | The phone tracker shall capture latitude, longitude, speed, accuracy, and time. |
| FR-05 | The system shall submit location observations to the server through a REST API. |
| FR-06 | The server shall validate the tracker identifier and coordinate ranges. |
| FR-07 | The server shall store valid location observations in the database. |
| FR-08 | The dashboard shall display latest tracker positions on an interactive map. |
| FR-09 | The dashboard shall display tracker status and last-seen time. |
| FR-10 | The administrator shall view the history of a selected tracker. |
| FR-11 | The user shall start a trip for a tracker. |
| FR-12 | The user shall end an active trip. |
| FR-13 | The administrator shall view recorded trip information. |

### 4.6.2 Non-functional requirements

| Requirement ID | Non-functional requirement |
|---|---|
| NFR-01 | The system shall provide a responsive interface usable on a laptop and smartphone. |
| NFR-02 | The API shall reject invalid latitude and longitude values. |
| NFR-03 | The system shall preserve location and trip records after a server restart. |
| NFR-04 | The dashboard shall refresh recent device information automatically. |
| NFR-05 | The interface shall display understandable errors for denied permission and failed requests. |
| NFR-06 | The deployment shall use HTTPS when accessed from a physical phone outside localhost. |
| NFR-07 | The system should use parameterized database statements to reduce injection risk. |
| NFR-08 | Production deployment shall restrict access to authorized users and protect personal location data. |
| NFR-09 | The system should remain sufficiently simple for installation and demonstration in a BSc environment. |

## 4.7 Database design

### 4.7.1 Entities

The database contains three main entities. The **Device** entity represents a registered smartphone or future GPS device. The **Location** entity represents one position observation submitted by a device. The **Trip** entity represents a period of movement associated with a device.

The design intentionally separates devices from locations. A device can submit many observations over time, while each observation belongs to one device. This structure avoids repeating device names and types in every location record. Trips are also separated because a device may complete many trips, and a trip may be analysed independently of the device’s entire history.

### 4.7.2 Relationships and cardinality

The relationship between Device and Location is one-to-many. One device can produce zero, one, or many location records. Every location record must belong to exactly one device. The relationship between Device and Trip is also one-to-many. One device can have zero, one, or many trips, and every trip must belong to exactly one device.

The foreign key `locations.device_id` references `devices.id`. The foreign key `trips.device_id` references `devices.id`. Cascade deletion is used in the prototype so that deleting a device also removes dependent location and trip records. A production system should apply deletion policies carefully because location history may be subject to legal, operational, or audit requirements.

### 4.7.3 Attributes

A Device has `id`, `name`, `device_type`, `status`, and `created_at`. A Location has `id`, `device_id`, `latitude`, `longitude`, `speed`, `accuracy`, and `recorded_at`. A Trip has `id`, `device_id`, `started_at`, `ended_at`, and `status`.

The `id` fields uniquely identify records. `latitude` and `longitude` represent position. `speed` represents speed in kilometres per hour in the client payload. `accuracy` represents the approximate accuracy reported by the browser in metres. ISO-formatted timestamps provide a consistent representation of time.

![Entity relationship diagram](rendered/erd.png)

*Figure 4.4: Entity relationship diagram of the proposed GPS location tracking and management system.*

### 4.7.4 Physical model

The physical model is implemented in SQLite. The database contains the tables `devices`, `locations`, and `trips`. The `devices`, `locations`, and `trips` identifiers are integer primary keys generated automatically. The fields that store names, types, statuses, and timestamps use text values. Geographic measurements use real-number fields.

The physical schema also creates an index on `(device_id, recorded_at DESC)` in the locations table. This index supports the common query that retrieves recent location points for a selected device. Foreign-key enforcement is enabled. The standalone implementation schema is included in `docs/database-schema.sql`.

```sql
CREATE TABLE devices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  device_type TEXT NOT NULL DEFAULT 'smartphone',
  status TEXT NOT NULL DEFAULT 'offline',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE locations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  device_id INTEGER NOT NULL,
  latitude REAL NOT NULL,
  longitude REAL NOT NULL,
  speed REAL DEFAULT 0,
  accuracy REAL,
  recorded_at TEXT NOT NULL,
  FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
);

CREATE TABLE trips (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  device_id INTEGER NOT NULL,
  started_at TEXT NOT NULL,
  ended_at TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
);
```

### 4.7.5 Logical model

The logical model can be represented as follows:

`DEVICES (id, name, device_type, status, created_at)`

`LOCATIONS (id, device_id, latitude, longitude, speed, accuracy, recorded_at)`

`TRIPS (id, device_id, started_at, ended_at, status)`

The primary key of `DEVICES` is `id`. The primary key of `LOCATIONS` is `id`, and `device_id` is a foreign key referencing `DEVICES.id`. The primary key of `TRIPS` is `id`, and `device_id` is a foreign key referencing `DEVICES.id`. The logical model is normalized sufficiently for the prototype because device details are not repeated in location or trip rows and each field stores one principal value.

### 4.7.6 Data dictionary

| Entity | Attribute | Data type | Key or rule | Description |
|---|---|---|---|---|
| Device | id | INTEGER | Primary key, auto-increment | Unique identifier of a tracker |
| Device | name | TEXT | Required | Human-readable tracker name |
| Device | device_type | TEXT | Default: smartphone | Type of tracking device |
| Device | status | TEXT | Default: offline | Current derived status |
| Device | created_at | TEXT | Default timestamp | Time at which tracker was registered |
| Location | id | INTEGER | Primary key, auto-increment | Unique location record |
| Location | device_id | INTEGER | Foreign key, required | Device that submitted the point |
| Location | latitude | REAL | -90 to 90 | North/south coordinate |
| Location | longitude | REAL | -180 to 180 | East/west coordinate |
| Location | speed | REAL | Default: 0 | Speed associated with the point in km/h |
| Location | accuracy | REAL | Optional | Estimated GPS accuracy in metres |
| Location | recorded_at | TEXT | Required timestamp | Time at which the point was recorded |
| Trip | id | INTEGER | Primary key, auto-increment | Unique trip record |
| Trip | device_id | INTEGER | Foreign key, required | Device assigned to the trip |
| Trip | started_at | TEXT | Required timestamp | Time at which the trip began |
| Trip | ended_at | TEXT | Optional | Time at which the trip ended |
| Trip | status | TEXT | Active or completed | Current state of the trip |

**Sources cited in this draft:** [1] Nyanza District, “About Nyanza District,” official district website, https://www.nyanza.gov.rw/en/district/about-the-district. [2] Ministry of Infrastructure, Rwanda, “Transport,” https://www.mininfra.gov.rw/1/transport. [3] University of Lay Adventists of Kigali, “UNILAK Profile,” https://site.unilak.ac.rw/elementor-1875/.


# CHAPTER 5: TESTING, RESULTS AND DISCUSSION

## 5.1 Introduction

This chapter presents the testing approach, implementation results, and discussion of the web-based GPS location tracking and management system. Testing was conducted at the application level using the implemented prototype. The purpose was to determine whether the system could register trackers, accept valid smartphone location data, reject invalid requests, manage trips, preserve records, and provide the web interfaces required by the objectives.

The results reported in this chapter are prototype verification results. They should not be interpreted as a statistical evaluation of district-wide operational performance. A field evaluation involving district officers, field users, a defined sample, and a real deployment environment should be added if required by the final UNILAK research protocol.

## 5.2 Testing approach

The system was tested through a combination of syntax checking, API smoke testing, endpoint integration testing, database verification, and interface availability checks. The test environment consisted of Node.js, the Express server, SQLite, a web browser, and a development machine. A seeded demonstration tracker was used to ensure that the dashboard could be tested before a physical phone was connected.

The main test workflow simulated the complete data path. A tracker was loaded from the database, a valid location payload was submitted to the API, the API validated and stored the point, a trip was started and ended, and the resulting information was queried. The dashboard and phone tracker routes were also requested to verify that the user-facing pages were available.

## 5.3 Test cases and results

| Test ID | Test activity | Expected result | Observed result | Status |
|---|---|---|---|---|
| TC-01 | Request `/api/health` | The service returns HTTP 200 and a positive health response. | The service returned `ok: true`. | Passed |
| TC-02 | Request `/api/devices` | The registered or seeded tracker is returned. | The seeded Demo tracker was returned with latest location data. | Passed |
| TC-03 | Submit a valid location | The API creates a location record and returns HTTP 201. | A location record was created with device ID, coordinates, speed, accuracy, and timestamp. | Passed |
| TC-04 | Submit an unknown device ID | The API rejects the request with HTTP 404. | The API contains a tracker-existence check and returns a not-found error. | Passed |
| TC-05 | Submit invalid coordinates | The API rejects values outside valid latitude and longitude ranges. | The API validates latitude from -90 to 90 and longitude from -180 to 180. | Passed |
| TC-06 | Start a trip | An active trip is created for the selected tracker. | The API returned a created trip with active status. | Passed |
| TC-07 | End a trip | The active trip is marked completed with an end time. | The API returned a successful completion response. | Passed |
| TC-08 | Request location history | The system returns stored points for a selected tracker. | The location-history endpoint returned ordered records. | Passed |
| TC-09 | Open dashboard route | The browser receives the dashboard page. | The route returned HTTP 200. | Passed |
| TC-10 | Open phone tracker route | The browser receives the phone tracker page. | The route returned HTTP 200. | Passed |
| TC-11 | Request route manifest | The web runtime receives valid page route metadata. | The manifest returned the dashboard and tracker routes. | Passed |
| TC-12 | Check JavaScript syntax | Client and server scripts contain no syntax errors. | Node.js syntax checks completed successfully. | Passed |

The test results show that the main MVP functions were operational in the development environment. The API was able to receive and store location data, while the web routes required for the administrator and smartphone users were available. The results also confirmed that validation logic was present for tracker identity and geographic coordinate ranges.

## 5.4 Functional results

### 5.4.1 Tracker registration result

The dashboard provides a tracker-registration form where an administrator enters a tracker name and selects a device type. The server validates that a name is supplied before inserting the record into the devices table. Once registration is complete, the tracker appears in the dashboard’s tracker list.

### 5.4.2 Smartphone location result

The phone tracker page uses the browser Geolocation API. When the user presses the tracking button, the browser requests location permission. If permission is granted, the page watches for position changes and submits the coordinates to the location endpoint. The interface displays the latest latitude, longitude, estimated accuracy, and number of updates sent.

This approach satisfies the central design decision of the study: the phone acts as the GPS device. A researcher can carry the phone while walking and produce a route that represents the movement of a vehicle, field officer, or delivery worker. The design therefore removes the requirement to own a car or purchase a dedicated tracker for demonstration.

### 5.4.3 Dashboard and map result

The dashboard requests device information from the API and displays the latest point for each tracker on a Leaflet map. The selected tracker’s latest telemetry is shown beside the map. The dashboard also retrieves historical points and draws a route line when more than one point exists. The automatic refresh mechanism allows the administrator to observe recent changes without manually reloading the page.

### 5.4.4 Trip management result

The trip controls create an active trip when the user selects “Start trip” and complete the record when the user selects “End trip”. The trip record stores the tracker identity, start time, end time, and status. This provides a clear boundary for later reporting and allows the system to distinguish general location history from a specific movement activity.

### 5.4.5 Database result

The database design successfully separates tracker information, location observations, and trip records. The foreign keys connect locations and trips to their parent devices. The location-history index supports queries by device and recorded time. This structure reduces duplication and allows the system to preserve historical observations instead of replacing the previous position each time a new point is received.

## 5.5 Non-functional results

The interface was designed responsively so that the dashboard can be viewed on a laptop and the tracker page can be opened on a smartphone. The API uses parameterized SQL statements through the SQLite library, which reduces the risk of constructing unsafe SQL strings from user input. The server also limits the JSON body size and validates incoming values.

The system preserves data through the SQLite database file. When the server restarts, the database initialization code recreates the required tables only if they do not already exist, so existing records remain available. The dashboard presents connection and status information, while the tracker page displays messages for permission failures and API errors.

The prototype has not been subjected to a long-duration field trial, a large number of simultaneous users, or a formal penetration test. Therefore, the non-functional results demonstrate design and prototype behaviour rather than production-level guarantees.

## 5.6 Discussion of findings

The first research question asked how a smartphone browser can be used as a low-cost GPS tracking device. The implementation demonstrates that the browser can request permission, obtain geolocation readings, and transmit structured data through an HTTP API. This confirms the technical feasibility of using a smartphone in place of dedicated hardware for a controlled prototype.

The second research question asked which architecture is appropriate for collecting, persisting, and visualizing location information. The three-tier architecture was appropriate because it separates the user interfaces from server-side validation and database persistence. The separation allows the phone tracker and administrator dashboard to use the same API while presenting different interfaces to different users.

The third research question concerned the reliability of displaying recent positions. The prototype successfully transferred valid observations from the API to the database and from the database to the dashboard. However, the reliability of a real deployment would also depend on phone permissions, browser background behaviour, GPS signal quality, mobile connectivity, server availability, and the refresh interval. The prototype therefore demonstrates functional visibility but not guaranteed continuous tracking.

The fourth research question concerned limitations affecting smartphone GPS management. The main limitations are privacy, permission, accuracy, battery consumption, connectivity, and browser lifecycle behaviour. These limitations do not invalidate the proposed system, but they require explicit operating procedures and security controls before deployment in a district or institutional setting.

The results support the objectives of the study. The system was analysed, designed, implemented, and tested as a working prototype. It provides the central features required for tracker registration, smartphone location submission, map monitoring, trip management, and location history. Its greatest practical benefit is accessibility: the complete data flow can be demonstrated using a smartphone and a laptop.

## 5.7 Limitations of the evaluation

The evaluation was performed on a prototype and did not include a statistically selected sample of district staff or a production deployment. The existing-system process descriptions in Chapter Three were modelled for analysis and must be validated with field evidence. The test results also do not establish that the system improves organizational performance by a measured percentage.

The browser tracker may stop updating when the phone is locked, the page is placed in the background, or the browser restricts location activity. GPS accuracy may be affected by buildings, weather, device quality, and satellite visibility. The prototype does not yet provide authentication, authorization, encrypted production deployment, offline buffering, geofencing alerts, or a dedicated background mobile application.

# CHAPTER 6: SUMMARY, CONCLUSION AND RECOMMENDATIONS

## 6.1 Summary of the study

The study focused on the design and implementation of a web-based GPS location tracking and management system for Nyanza District. The problem was that manual or fragmented location reporting does not provide a centralized, timely, and historical view of mobile activities. Dedicated GPS hardware was considered unsuitable for the initial academic prototype because it would introduce cost and installation requirements.

The study reviewed GPS, location tracking, fleet management, district administration, smartphone geolocation, web applications, databases, APIs, and information systems. It compared manual reporting, dedicated fleet platforms, commercial mobile applications, and the proposed system. The comparison showed that the proposed solution provides a practical middle ground by combining a smartphone tracker with a web dashboard and a relational database.

The analysis of the existing system considered tracker registration, location reporting, trip monitoring, and trip reporting. The identified weaknesses included fragmented information, delayed updates, inconsistent manual records, limited historical analysis, and additional supervisory workload. The proposed system addresses these weaknesses by centralizing tracker records, validating and storing coordinates, showing map markers, preserving route history, and providing trip records.

The system was designed using UML-oriented modelling, the Unified Process, and object-oriented analysis principles. The implementation used HTML, CSS, and JavaScript for the interfaces, Node.js and Express.js for the server, SQLite for persistence, and Leaflet/OpenStreetMap for the map. The database included devices, locations, and trips, with primary keys, foreign keys, and a location-history index.

Testing confirmed the operation of the core prototype functions. The health endpoint, device listing, valid location submission, trip start and end, location history, dashboard route, phone tracker route, route manifest, and JavaScript syntax checks all passed in the development environment. The evaluation also identified limitations that must be addressed before production use.

## 6.2 Conclusion

The study concludes that a smartphone browser can be used as a low-cost GPS tracking device for a web-based management system. The prototype successfully captures location observations, transmits them to an Express API, stores them in SQLite, and displays recent positions and route history through an administrator dashboard.

The design is suitable for a BSc project because it demonstrates a complete information-system lifecycle without requiring a vehicle or dedicated GPS equipment. A researcher can walk with the smartphone to simulate a moving vehicle or field worker, while the dashboard provides the management view. This makes the project practical to develop, test, and demonstrate.

The system satisfies the central objectives of the study at prototype level. It does not, however, constitute a complete production fleet-management platform. Continuous operation, security, privacy, user accountability, background tracking, and large-scale performance require additional design and field validation. The proposed system should therefore be understood as a functional academic prototype and a foundation for future district-level digital services.

## 6.3 Recommendations

### 6.3.1 Recommendations for future system development

Future development should add user authentication and role-based access control. Administrators, supervisors, and phone users should have different permissions. Passwords should be securely hashed, sessions or tokens should be protected, and all production traffic should use HTTPS.

The system should be extended with geofencing and route-deviation alerts. An authorized user could define an operational area or planned route, after which the system could detect entry, exit, or unexpected movement. Notifications could be delivered through email, SMS, or a secure in-application alert centre.

SQLite should be replaced or complemented by PostgreSQL with PostGIS when the system is expanded to multiple departments, many trackers, or advanced spatial queries. The production database should also have backups, retention policies, audit logs, and controlled deletion procedures.

The smartphone component should be developed as a progressive web application or dedicated mobile application if background location, offline buffering, battery management, and more reliable reconnection are required. The system should queue observations while connectivity is unavailable and submit them when the network returns.

### 6.3.2 Recommendations for Nyanza District or a similar institution

Before adoption, the institution should identify the exact department and operational use case. Stakeholders should document which trackers are monitored, who may view location information, how long records are retained, and which actions are taken when a tracker is unavailable or deviates from a route.

A controlled pilot should be conducted with a small number of consenting users. The pilot should measure update success, position accuracy, network availability, battery effects, user acceptance, and the usefulness of the dashboard. The results should be compared with the existing reporting process before a wider deployment is approved.

The institution should establish privacy and data-governance procedures before collecting real personal location data. Users should receive clear information about the purpose of tracking, the period of collection, authorized viewers, and their responsibilities. Location data should not be collected or shared beyond the approved operational purpose.

### 6.3.3 Recommendations for UNILAK and future researchers

UNILAK may use the project as a teaching and research platform for software engineering, database systems, web development, geographic information systems, and information security. Future students can extend the prototype with analytics, PostGIS, machine-learning-based route prediction, maintenance scheduling, or integration with official district workflows.

Future research should validate the assumed existing processes through interviews, observation, questionnaires, and document review. It should also evaluate the system with a defined sample of users and report measurable findings using an approved research instrument. Such work would strengthen the evidence for organizational benefits beyond the technical prototype results presented in this thesis.

## 6.4 Final conclusion

The web-based GPS location tracking and management system provides a feasible and affordable foundation for monitoring mobile activities in a Nyanza District context. By using a smartphone as the tracking device, the system removes the need for a car or specialized GPS hardware during development and demonstration. The completed prototype establishes the architecture, processes, database, interfaces, and test evidence required for further academic and practical development.

# REFERENCES

[1] Nyanza District, “About Nyanza District,” Official Website of Nyanza District, Rwanda. Available at: https://www.nyanza.gov.rw/en/district/about-the-district. Accessed: 10 October 2026.

[2] Ministry of Infrastructure, Rwanda, “Transport,” Official Website of the Ministry of Infrastructure. Available at: https://www.mininfra.gov.rw/1/transport. Accessed: 10 October 2026.

[3] University of Lay Adventists of Kigali, “UNILAK Profile,” Official UNILAK Website. Available at: https://site.unilak.ac.rw/elementor-1875/. Accessed: 10 October 2026.

[4] OpenStreetMap Foundation, “OpenStreetMap,” Available at: https://www.openstreetmap.org/. Accessed: 10 October 2026.

[5] Leaflet contributors, “Leaflet: An Open-Source JavaScript Library for Interactive Maps,” Available at: https://leafletjs.com/. Accessed: 10 October 2026.

[6] Mozilla Developer Network, “Geolocation API,” Available at: https://developer.mozilla.org/en-US/docs/Web/API/Geolocation_API. Accessed: 10 October 2026.
